﻿public enum GameType
{
	Unassigned,
	React,
}
