import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Lamicela_Asteroids extends PApplet {

int count; //keeps track of number of asteroids
int left;  //when it hits 0, advance level
boolean empty; //indicates when all asteroids have been destroyed
//player 1 stats
int score1;
int lives1;
//player 2 stats
int score2;
int lives2;
boolean twop;
Rock test;
InputManager control;
Rock[] field;

int level; //
int mode;  //1 or 2 players
int turn;  //alternates to take turns
Ship player;
Bullet zap;

public void setup(){
  
  background(0);
  turn = 1;
  twop = false;
  control = new InputManager();
  mode = 0;
  count = 8;
  lives1 = 3;
  lives2 = 3;
  level = 1;
  player = new Ship();
  zap = new Bullet(player);
  field = new Rock[count];
  left = 3*count;
  for(int a = 0; a < count; a++){
    field[a] = new Rock();
  }
}

public void draw(){
  keyPressed();
  keyReleased();
  background(0);
  for(Rock r:field){
    r.Update();
    r.Display();
    r.split1.Update();
    r.split1.Display();
    r.split2.Update();
    r.split2.Display();
    if(r.active == true || r.split1.active == true || r.split2.active == true){
      empty = false;
    }
    else empty = true;
  }
  if(left==0){
    left=3*count;
    level++;
    for(int a = 0; a < count; a++){
      field[a] = new Rock();
    }
  }
   
  zap.Update();
  zap.Display();
  fill(0xffFFFFFF);
  //Mode 0: Title Screen
  if(mode == 0){
    textSize(40);
    text("Asteroids", 50,100);
    textSize(20);
    text("Press 1 for 1 player game",50,200);
    text("Press 2 for 2 player game", 50,220);
    text("Controls",50,250);
    text("Q -- Left            W -- Right",70,270);
    text("O -- Thrust        P  -- Fire",70,290);
    text("Spacebar -- Warp",70,310);
    
  }
  //Modes 1 and 2: Play Mode
  if(mode == 1 || mode == 2){
    player.Update();
    if(player.warp == 0)player.Display();
    
    if(lives1 == 0){
      if(mode == 1) mode = 3;
      else if(mode == 2 && lives2 == 0) mode = 3;
    }
  }
  //scoreboard
  textSize(20);
    fill(0xffFFFFFF);
    if(mode == 1 || mode == 2 || mode == 3){
      text("1UP: " + score1,20,20);
      text("Lives: " + lives1, 20,40);  
      text("Level " + level,200,20);
      if(turn == 1)ellipse(10,20,5,5);
      else if(turn == 2)ellipse(310,20,5,5);
    }
    if(mode == 2 || mode == 3 && twop == true){
      text("2UP: " + score2,320,20);
      text("Lives: " + lives2,320,40);
    }
  //Mode 3: Game Over
  if(mode == 3){
    textSize(40);
    text("GAME OVER",140,240);
    textSize(20);
    text("Press 'R' to restart",140,280);
    if(control.isKeyPressed(82)) reset();
  }
  
}

public void reset(){
  player.position.x = width/2;
  player.position.y = height/2;
  score1 = 0;
  score2 = 0;
  lives1 = 3;
  lives2 = 3;
  mode = 0;
  setup();
}

public void keyPressed(){
  control.recordKeyPress(keyCode);
  if(mode == 0){
    if(key == '1') mode = 1;
    else if(key == '2'){
      mode = 2;
      twop = true;
    } 
    //if(control.isKeyPressed('q')) player.Left();
    
  }
}
public void keyReleased(){
  control.recordKeyRelease(keyCode);
}
class Bullet{
  PShape bullet;
  float r;
  int X;
  int Y;
  int rad;
  boolean active;
  PVector velocity, acceleration, position, direction;
  float speed, maxSpeed, range, distance;
  //as bullet travels, distance will count up until it exceeds range, then it becomes inactive
  
  Bullet(Ship source)
  {
    rad = 50;
    range = 100;
    distance = 0;
    acceleration = new PVector(0,0);
    velocity = new PVector(0,0);
    position = new PVector(source.position.x,source.position.y);
    direction = source.direction.copy();
    speed = 5.0f;
    maxSpeed = 5.0f;
    active = false;
  }
  
  public void Update(){
    if(active == true){
      distance++;
      acceleration = PVector.mult(direction,speed);
      velocity.add(acceleration);
      velocity.limit(maxSpeed);
      position.add(velocity);
      //wrap around
      if(position.x > width + 40) position.x = -40;
      if(position.x < -40) position.x = width + 40;
      if(position.y > height + 40) position.y = -40;
      if(position.y < -40) position.y = height + 40;
      //end at max range
      if(distance >= range) active = false;
    }
  }
  public void Display(){
    if(active == true){
      pushMatrix();
      translate(position.x,position.y);
      rotate(direction.heading());
      stroke(0xffFFFFFF);
      fill(0,0,0,0);
      ellipse(0,0,5,5);
      popMatrix();
    }
  }
}
class InputManager {
  boolean[] keys;

  InputManager() {
    keys = new boolean[256];
  }

  public void recordKeyPress(int k) {
    keys[k] = true;
  }

  public void recordKeyRelease(int k) {
    keys[k] = false;
  }

  public boolean isKeyPressed(int k) {
    return keys[k];
  }

  public boolean isKeyReleased(int k) {
    return !keys[k];
  }
}
class Pebble{
  PVector velocity, acceleration, position, direction;
  float speed, maxSpeed;
  PShape pebble;
  boolean active;
  int rad;
  Pebble(Rock source){
    
    rad = 40;
    speed = 1.0f + level/20;
    maxSpeed = 1.0f + level/20;
    acceleration = new PVector(0,0);
    velocity = new PVector(0,0);
    position = new PVector(source.position.x, source.position.y);
    direction = PVector.fromAngle(radians(random(0,360)));
    active = false;
  }
  
  public void Update(){
    if(active == true){
      detectCollisions(zap);
      acceleration = PVector.mult(direction,speed);
      velocity.add(acceleration);
      velocity.limit(maxSpeed);
      position.add(velocity);
      //wrap around
      if(position.x > width + 20) position.x = -20;
      if(position.x < -20) position.x = width + 20;
      if(position.y > height + 20) position.y = -20;
      if(position.y < -20) position.y = height + 20;
    }
  }
  public void Display(){
    if(active == true){
      pushMatrix();
      translate(position.x,position.y);
      rotate(direction.heading());
      stroke(0xffFFFFFF);
      fill(0,0,0,0);
      ellipse(0,0,rad,rad);
      popMatrix(); 
    }
  }
  
  public void Explode(){
    if(turn == 1) score1+=10;
    else score2+=10;
    
    left--;
    active = false;
  }
  
  public void detectCollisions(Bullet disc){
    //PShape dist = createShape(LINE,X,Y,disc.X,disc.Y);
    float distX = disc.position.x - position.x;
    float distY = disc.position.y - position.y;
    float dist = sqrt((distX*distX)+(distY*distY));
    int radTotal = (disc.rad+rad)/4;
    if(dist < radTotal && disc.active == true){
      Explode();
      disc.active = false;
    }
  }
}
class Rock{
  PVector velocity, acceleration, position, direction;
  float speed, maxSpeed;
  PShape rock;
  Pebble split1;
  Pebble split2;
  boolean active;
  int rad;
  
  Rock(){
    rad = 80;
    speed = 1.0f + level/20;
    maxSpeed = 1.0f + level/20;
    acceleration = new PVector(0,0);
    velocity = new PVector(0,0);
    position = new PVector(random(width), random(height));
    direction = PVector.fromAngle(radians(random(0,360)));
    active = true;
    split1 = new Pebble(this);
    split2 = new Pebble(this);
  }
  
  public void Update(){
    
    if(active == true){
      detectCollisions(zap);
      acceleration = PVector.mult(direction,speed);
      velocity.add(acceleration);
      velocity.limit(maxSpeed);
      position.add(velocity);
      //wrap around
      if(position.x > width + 40) position.x = -40;
      if(position.x < -40) position.x = width + 40;
      if(position.y > height + 40) position.y = -40;
      if(position.y < -40) position.y = height + 40;
    }
      
    
    
  }
  public void Display(){
    if(active == true){
      pushMatrix();
      translate(position.x,position.y);
      rotate(direction.heading());
      stroke(0xffFFFFFF);
      fill(0,0,0,0);
      ellipse(0,0,rad,rad);
      popMatrix();
    }
    
  }
  
  public void Explode(){
    if(turn == 1) score1+=10;
    else score2+=10;
    
    left--;
    active = false;
    split1 = new Pebble(this);
    split1.active = true;
    split2 = new Pebble(this);
    split2.active = true;
    split2.direction = PVector.fromAngle(radians(random(0,360)));
  }
  public void detectCollisions(Bullet disc){
    //PShape dist = createShape(LINE,X,Y,disc.X,disc.Y);
    float distX = disc.position.x - position.x;
    float distY = disc.position.y - position.y;
    float dist = sqrt((distX*distX)+(distY*distY));
    int radTotal = (disc.rad+rad)/4;
    if(dist < radTotal && disc.active == true){
      Explode();
      disc.active = false;
    }
  }
}
class Ship{
  PShape hitbox;
  boolean hit;
  boolean active;
  boolean blink; //toggle visiblity during mercy
  int rad;
  int warp; //timer counting down to re-entry
  int mercy; //invincibility to prevent spawnkills
  int boom; //timer for explosion animation
  
  PVector velocity, acceleration, position, direction;
  float speed, maxSpeed;
  
  Ship(){
    blink = true;
    hit = false;
    velocity = new PVector(0,0);
    acceleration = new PVector(0,0);
    position = new PVector(width/2, height/2);
    direction = PVector.fromAngle(radians(270));
    speed = 0.1f;
    maxSpeed = 3.0f;
    rad=90;
  }
  
  public void Update(){
    
    hitbox = createShape(ELLIPSE,position.x/2,position.y/2,rad,rad);
    if(warp == 0){
      Fire();
      Left();
      Right();
      Thrust();
      Drift();
      Warp();
      if(mercy == 0){
        for(int r = 0; r < count; r++){
          if(hit==false)
          detectCollisions(field[r]);
          detectSmallCollisions(field[r].split1);
          detectSmallCollisions(field[r].split2);
        }
      }
      if(hit == true) Explode();
    }
    
    position.add(velocity);
//println(acceleration);
    if(mercy > 0){
       mercy--;
       if(blink == true) blink = false;
       else blink = true;
    }
    if(mercy == 0) blink = true;
    if(warp > 0) warp--;
    //wrap around
    if(position.x > width + 20) position.x = -20;
    if(position.x < -20) position.x = width + 20;
    if(position.y > height + 20) position.y = -20;
    if(position.y < -20) position.y = height + 20;
  }
  public void Display(){
    pushMatrix();
    translate(position.x,position.y);
    rotate(direction.heading());
    if(blink == true){
    stroke(0xffFFFFFF);
    }
    else stroke(0);
    if(hit == true)stroke(0xffFF0000);
    fill(0,0,0,0);
    triangle(15,0,-10,10,-10,-10);
    popMatrix();
  }
  
  //ship actions
  public void Fire(){
    if(control.isKeyPressed(80))
    if(zap.active == false){
      zap = new Bullet(this);
      zap.active = true;
    }
    
  }
  public void Left(){
    if(control.isKeyPressed(81)) 
    direction.rotate(-0.1f);
  }
  public void Right(){
    if(control.isKeyPressed(87)) 
    direction.rotate(0.1f);
  }
  public void Thrust(){
    if(control.isKeyPressed(79)){
      acceleration = PVector.mult(direction,speed);
      velocity.add(acceleration);
      velocity.limit(maxSpeed);
    }
  }
  public void Drift(){
    if(control.isKeyReleased(79)){
      if(velocity.x != 0) velocity.x -= velocity.x/100;
      if(velocity.y != 0) velocity.y -= velocity.y/100;
    }
  }
  public void Warp(){
    if(control.isKeyPressed(32)){
      warp = 60;
      position.x = random(0, width);
      position.y = random(0,height);
      velocity.sub(velocity);
    }
    
  }
  public void Explode(){
    velocity.sub(velocity);
    if(mode == 1){
      lives1--;
    }
    else if(mode == 2){
      if(turn == 1){
        lives1--;
        turn = 2;
      } 
      else{
        lives2--;
        turn = 1;
      } 
    }
    Spawn();
  }
  public void Spawn(){
    hit = false;
    direction = PVector.fromAngle(radians(270));
    mercy = 300;
    boom = 100;
    velocity.sub(velocity);
    position.x = width/2;
    position.y = height/2;
  }
  public void detectCollisions(Rock disc){
    //PShape dist = createShape(LINE,X,Y,disc.X,disc.Y);
    float distX = disc.position.x - position.x;
    float distY = disc.position.y - position.y;
    float dist = sqrt((distX*distX)+(distY*distY));
    int radTotal = (disc.rad+rad)/4;
    if(dist < radTotal && disc.active == true){
      hit = true;
      return;
    }
  }
  public void detectSmallCollisions(Pebble disc){
    //PShape dist = createShape(LINE,X,Y,disc.X,disc.Y);
    float distX = disc.position.x - position.x;
    float distY = disc.position.y - position.y;
    float dist = sqrt((distX*distX)+(distY*distY));
    int radTotal = (disc.rad+rad)/4;
    if(dist < radTotal && disc.active == true){
      hit = true;
      return;
    }
  }
}
  public void settings() {  size(480,640); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Lamicela_Asteroids" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
